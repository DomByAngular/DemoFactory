
	As a policy, BasicSample.Core.Data should ONLY contain interfaces.
	Data access object _implementations_ should be found within the BasicSample.Data project.