CastleComponents.config defines all the objects which are available for dependency injection.

NorthwindNHibernate.config defines the communications settings for NHibernate to communicate with the Northwind database.

A separate <DbName>NHibernate.config file should be created for each database that you need to communicate with, concurrently.
It's OK if you just have one, this multi-database setup works just fine with one database as well.