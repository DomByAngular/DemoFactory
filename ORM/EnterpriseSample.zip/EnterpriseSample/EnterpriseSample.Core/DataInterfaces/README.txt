
	As a policy, EnterpriseSample.Core.Data should ONLY contain interfaces.
	Data access object _implementations_ should be found within the EnterpriseSample.Data project.