﻿using System;
using System.Collections.Generic;
using NHibernate;

namespace MultiFactory
{
    public interface ISessionFactoryProvider : IEnumerable<ISessionFactory>, IDisposable
    {
        ISessionFactory GetFactory(string factoryId);
        event EventHandler<EventArgs> BeforeCloseSessionFactory;
    }
}