﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            var sfp=new MultiSessionFactoryProvider();
            var sf1 = sfp.GetFactory("FACTORY1");
            var sf2 = sfp.GetFactory("FACTORY2");

            var session = sf1.OpenSession();
            //
            var session2 = sf2.OpenSession();

        }
    }
}
