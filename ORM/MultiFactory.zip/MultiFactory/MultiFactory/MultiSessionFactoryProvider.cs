﻿using System;
using System.Collections;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Engine;

namespace MultiFactory
{
    class MultiSessionFactoryProvider : ISessionFactoryProvider
    {
        private IConfigurationProvider _mfc;
        private string _defaultSessionFactoryName;
        private Dictionary<string, ISessionFactory> _sfs = new Dictionary<string, ISessionFactory>(4);

        public MultiSessionFactoryProvider() : this(new DefaultMultiFactoryConfigurationProvider()) { }

        public MultiSessionFactoryProvider(IConfigurationProvider configurationProvider)
        {
            if (configurationProvider == null)
            {
                throw new ArgumentNullException("configurationProvider");
            }
            _mfc = configurationProvider;
        }

        public ISessionFactory GetFactory(string factoryId)
        {
            Initialize();
            return string.IsNullOrEmpty(factoryId)
                            ? InternalGetFactory(_defaultSessionFactoryName)
                            : InternalGetFactory(factoryId);
        }

        public event EventHandler<EventArgs> BeforeCloseSessionFactory;

        public void Initialize()
        {
            if (_sfs.Count != 0)
            {
                return;
            }
            foreach (var cfg in _mfc.Configure())
            {
                var sf = (ISessionFactoryImplementor)cfg.BuildSessionFactory();
                var sessionFactoryName = sf.Settings.SessionFactoryName;
                if (!string.IsNullOrEmpty(sessionFactoryName))
                {
                    sessionFactoryName = sessionFactoryName.Trim();
                }
                else
                {
                    throw new ArgumentException("The session-factory-id was not register; you must assign the name of the factory, example: <session-factory name='HereTheFactoryName'>");
                }
                if (string.IsNullOrEmpty(_defaultSessionFactoryName))
                {
                    _defaultSessionFactoryName = sessionFactoryName;
                }
                _sfs.Add(sessionFactoryName, sf);
            }
            _mfc = null; // after built the SessionFactories the configuration is not needed
        }

        private ISessionFactory InternalGetFactory(string factoryId)
        {
            try
            {
                return _sfs[factoryId];
            }
            catch (KeyNotFoundException)
            {
                throw new ArgumentException("The session-factory-id was not register", "factoryId");
            }
        }

        private void DoBeforeCloseSessionFactory()
        {
            if (BeforeCloseSessionFactory != null)
            {
                BeforeCloseSessionFactory(this, new EventArgs());
            }
        }

        public IEnumerator<ISessionFactory> GetEnumerator()
        {
            Initialize();
            return _sfs.Values.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~MultiSessionFactoryProvider()
        {
            Dispose(false);
        }
        private bool _disposed;

        private void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    foreach (var sessionFactory in _sfs.Values)
                    {
                        if (sessionFactory != null)
                        {
                            DoBeforeCloseSessionFactory();
                            sessionFactory.Close();
                        }
                    }
                    _sfs = new Dictionary<string, ISessionFactory>(4);
                }
                _disposed = true;
            }
        }
    }
}
