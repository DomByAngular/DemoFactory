﻿using System;
using System.Collections.Generic;
using NHibernate.Cfg;

namespace MultiFactory
{
    public interface IConfigurationProvider
    {
        IEnumerable<Configuration> Configure();
        event EventHandler<ConfiguringEventArgs> BeforeConfigure;
        event EventHandler<ConfigurationEventArgs> AfterConfigure;
    }

    public class ConfiguringEventArgs : EventArgs
    {
        public ConfiguringEventArgs(Configuration configuration)
        {
            Configuration = configuration;
            Configured = false;
        }
        public Configuration Configuration { get; private set; }
        public bool Configured { get; set; }
    }

    public class ConfigurationEventArgs : EventArgs
    {
        public ConfigurationEventArgs(Configuration configuration)
        {
            Configuration = configuration;
        }
        public Configuration Configuration { get; private set; }
    }
}