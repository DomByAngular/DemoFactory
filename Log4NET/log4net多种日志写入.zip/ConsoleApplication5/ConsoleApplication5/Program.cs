﻿using System;
using System.Collections.Generic;
using System.Text;
using log4net;
using System.Reflection;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            //创建日志记录组件实例
            ILog log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            //记录严重错误
            log.Fatal("严重错误");
            log.Fatal("严重错误", new Exception("发生了一个致命错误"));
            //记录错误日志
            log.Error("错误");
            log.Error("错误", new Exception("发生了一个异常"));
            //记录警告信息
            log.Warn("警告");
            log.Error("警告", new Exception("有一个警告信息"));
            //记录一般信息
            log.Info("一般信息");
            log.Error("一般信息", new Exception("发出一个一般信息"));
            //记录调试信息
            log.Debug("调试信息");
            log.Error("调试信息", new Exception("发生了一个调试信息"));
            Console.Read();
        }
    }
}
