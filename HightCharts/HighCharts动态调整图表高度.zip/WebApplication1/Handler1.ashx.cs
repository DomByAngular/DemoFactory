﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using Chen.Common;

namespace WebApplication1
{
    /// <summary>
    /// Handler1 的摘要说明
    /// </summary>
    public class Handler1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            var x = Convert.ToInt32(context.Request.Form["x"]);
            var y = Convert.ToInt32(context.Request.Form["y"]);
            var t = context.Request.Form["t"];
            //
            var dt = getDt(x,y);
            HighCharts hc = new HighCharts();
            hc.title = "图表示例";
            hc.showY = true;
            hc.subtitle = "当日统计结果";
            hc.type = t;
            var charString = hc.GetChart(dt);
            context.Response.Write(charString);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private DataTable getDt(int x, int y)
        {
            var dt = new DataTable();
            dt.Columns.Add("x1", typeof(string));
            for (var i = 0; i < y; i++)
            {
                dt.Columns.Add("y" + i, typeof(int));
            }
            for (var i = 0; i < x; i++)
            {
                var dr = dt.NewRow();
                dr["x1"] = "中国人民解放军基地" + i + "号";
                for (var ii = 0; ii < y; ii++)
                {
                    dr["y" + ii] = x * (1 + ii);
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
    }
}