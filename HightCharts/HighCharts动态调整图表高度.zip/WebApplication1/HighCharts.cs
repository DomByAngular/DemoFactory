﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Chen.Common
{
    public class HighCharts
    {
        public string title = string.Empty;
        public string subtitle = string.Empty;
        public bool showY = false;
        public string type = string.Empty;

        private string xAxis = string.Empty;
        private string yAxis = string.Empty;
        private string series = string.Empty;
        private int xLen = 0;
        private int yLen = 0;

        public string GetChart(DataTable dt)
        {
            //记录Y轴数据
            var arrYData = new string[dt.Columns.Count - 1];
            //Y轴数据模板
            var tem = @"{name: '{0}',data: [{1}]}";
            for (var i = 0; i < dt.Columns.Count; i++)
            {
                var arr = new string[dt.Rows.Count];
                for (var j = 0; j < dt.Rows.Count; j++)
                {
                    //将空数据转换为0 
                    var value = dt.Rows[j][i].ToString();
                    if (string.IsNullOrEmpty(value))
                    {
                        value = "0";
                    }
                    arr[j] = value;
                }
                if (i > 0)
                {
                    arrYData[i - 1] = tem.Replace("{0}", dt.Columns[i].ColumnName)
                        .Replace("{1}", string.Join(",", arr));
                }
                else
                    xAxis = "'" + string.Join("','", arr) + "'";
            }
            series = string.Join(",", arrYData);
            //记录x轴和y轴的长度
            xLen = dt.Rows.Count;
            yLen = dt.Columns.Count - 1;
            return GetChart();
        }

        private string GetChart()
        {
            var tem = @"<script type='text/javascript'> var chart = new Highcharts.Chart({chart: {renderTo: 'container',type: '#type'},title: {text: '#title'},subtitle: {text: '#subtitle'},xAxis: {categories: [#xAxis]},yAxis: {min: 0,title: {text: '#yAxis'}},legend: {backgroundColor: '#FFFFFF',reversed: true},tooltip: {formatter: function() {return ''+this.x +': '+ this.y +' 条';}},plotOptions: {column: {pointPadding: 0.2,borderWidth: 0}},series: [#series]});</script>";
            tem = tem.Replace("#title", title)
                .Replace("#series", series)
                .Replace("#subtitle", subtitle)
                .Replace("#xAxis", xAxis)
                .Replace("#yAxis", yAxis)
                .Replace("#showY", showY.ToString().ToLower())
                .Replace("#type", type);
            var retStr = new StringBuilder("{");
            retStr.AppendFormat("\"x\":{0},\"y\":{1},\"chart\":\"", xLen, yLen);
            retStr.Append(tem.ToString());
            retStr.Append("\"}");
            return retStr.ToString().Replace("\n", "");
        }
    }
}
