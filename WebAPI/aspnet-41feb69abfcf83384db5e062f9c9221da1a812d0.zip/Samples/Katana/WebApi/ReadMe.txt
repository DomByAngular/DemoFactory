HelloWorld Sample
----------------------

OWIN is a HTTP server API abstraction at enables application portability across
various servers. This sample demonstrates how to use the WebApi framework on
OWIN based servers.

For more information about OWIN, please see
http://www.owin.org/

This sample is provided as part of the ASP.NET Web Stack sample repository at
http://aspnet.codeplex.com/

For more information about the samples, please see
http://go.microsoft.com/fwlink/?LinkId=261487
