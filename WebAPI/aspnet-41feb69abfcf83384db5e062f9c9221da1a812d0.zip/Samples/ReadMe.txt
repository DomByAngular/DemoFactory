ASP.NET Web Stack Samples (MVC, Web API, and Web Pages)

For more information about ASP.NET Web Stack samples, please see these references:

* List of ASP.NET MVC samples: http://www.asp.net/mvc/samples
* List of ASP.NET Web API samples: http://www.asp.net/web-api/samples
* List of ASP.NET Web Pages samples: http://www.asp.net/web-pages/samples

For details about each sample, see the ReadMe.txt within the same folder
as the sample solution.

For more general information about ASP.NET, please see these references:

* ASP.NET general information, overview, walkthroughs: http://www.asp.net/
* ASP.NET Web Stack source code repository: http://aspnetwebstack.codeplex.com/

For more information about running the samples, please see 
http://go.microsoft.com/fwlink/?LinkId=261486
