ASP.NET MVC Attribute Routing sample
-----------------------------------
This sample demonstrates the use of attribute routing in ASP.NET MVC.

See the various controller classes for details about what features are being demonstrated. 

To run, just launch the web application in the visual studio debugger.

For more information on attribute routing in ASP.NET MVC, see http://go.microsoft.com/fwlink/?LinkID=324821