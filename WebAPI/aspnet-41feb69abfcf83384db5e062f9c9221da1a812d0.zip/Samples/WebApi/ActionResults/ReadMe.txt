ASP.NET Web API Action Results Sample
-----------------------------------
This sample demonstrates custom action results with Web API. An
OkTextPlainResult provides a way to return text content via Web API. An
OkFileDownloadResult provides a way to return an attachment-style file download
to a browser via Web API. 

To see the sample, run the website and click each of the links on the page that
appears.

For more information about the samples, please see
http://go.microsoft.com/fwlink/?LinkId=261487