using System.Web.UI;

namespace PrimaryKeysConfigTest.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}