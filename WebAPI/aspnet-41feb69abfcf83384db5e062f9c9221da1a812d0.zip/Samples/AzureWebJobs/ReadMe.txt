Windows Azure WebJobs SDK Samples
-----------------------------------

This folder contains C# samples for the Windows Azure WebJobs SDK.

For more information about the WebJobs feature of Windows Azure Web Sites, 
see http://go.microsoft.com/fwlink/?LinkId=390226